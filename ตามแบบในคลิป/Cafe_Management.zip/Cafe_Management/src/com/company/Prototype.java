package com.company;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class Prototype extends JFrame{
    private JLabel lb1;
    private JPanel pn1;
    private JPanel pn2;
    private JCheckBox latteCheckBox;
    private JCheckBox icedCappuccinoCheckBox;
    private JCheckBox icedLatteCheckBox;
    private JCheckBox espressoCheckBox;
    private JCheckBox cappuccinoCheckBox;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JCheckBox coffeeCakeCheckBox;
    private JCheckBox queenSParkChocolateCheckBox;
    private JCheckBox redVelvetCakeCheckBox;
    private JCheckBox bostonCreamPieCheckBox;
    private JCheckBox blackForestCakeCheckBox;
    private JCheckBox lagosChocolateCakeCheckBox;
    private JCheckBox kilburnChocolateCakeCheckBox;
    private JCheckBox carltonHillChocolateCakeCheckBox;
    private JTextField textField6;
    private JTextField textField7;
    private JTextField textField8;
    private JTextField textField9;
    private JTextField textField10;
    private JTextField textField11;
    private JTextField textField12;
    private JTextField textField13;
    private JTextArea textArea1;
    private JTextField a0TextField;
    private JTextField a0TextField1;
    private JTextField a10TextField;
    private JTextField a0TextField2;
    private JTextField a0TextField3;
    private JTextField a0TextField4;
    private JButton totalButton;
    private JButton exitButton;
    private JButton receiptButton;
    private JButton resetButton;
    private JPanel pn3;
    private JPanel pn4;
    private JPanel pn5;
    private JPanel pn6;
    private JPanel pn7;
    private JPanel pn8;
    int [] drinks = new int[5];//จำนวนเครื่องดื่ม//
    int [] cakes = new int[8]; //จำนวนชิ้นของเค้ก//
    double [] cost = new double[6]; //Cost of Drinks,Cost of Cakes,Service Charge,Tax,Sub Total,Total//
    double [] i = new double[13]; //เก็บราคาของเครื่องดื่มและเค้ก//

    public Prototype(){
        add(pn1);

        //==========Button ActionListener==========//
        totalButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cost[0] = Double.parseDouble(a0TextField.getText()); //Cost of Drinks//
                cost[1] = Double.parseDouble(a0TextField1.getText()); //Cost of Cakes//
                cost[2] = Double.parseDouble(a10TextField.getText()); //Service Charge//
                double CostTotal = (cost[0]+cost[1]+cost[2]);
                if(e.getSource().equals(totalButton)){
                    String tax = String.format("%.2f",(CostTotal / 100) * 7);
                    a0TextField2.setText(tax);

                    double subtotal = (CostTotal);
                    String sub = String.format("%.2f",subtotal);
                    a0TextField3.setText(sub);

                    double total = (subtotal);
                    String Total = String.format("%.2f",total+((CostTotal / 100) * 7));
                    a0TextField4.setText(Total);
                }
            }
        });
        receiptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                drinks[0] = Integer.parseInt(textField1.getText());
                drinks[1] = Integer.parseInt(textField2.getText());
                drinks[2] = Integer.parseInt(textField3.getText()); //จำนวนเครื่องดื่มแต่ละอย่าง//
                drinks[3] = Integer.parseInt(textField4.getText());
                drinks[4] = Integer.parseInt(textField5.getText());

                cakes[0] = Integer.parseInt(textField6.getText());
                cakes[1] = Integer.parseInt(textField7.getText());
                cakes[2] = Integer.parseInt(textField8.getText());
                cakes[3] = Integer.parseInt(textField9.getText());
                cakes[4] = Integer.parseInt(textField10.getText()); //จำนวนเค้กแต่ละอย่าง//
                cakes[5] = Integer.parseInt(textField11.getText());
                cakes[6] = Integer.parseInt(textField12.getText());
                cakes[7] = Integer.parseInt(textField13.getText());

                cost[3] = Double.parseDouble(a0TextField2.getText()); //Tax//
                cost[4] = Double.parseDouble(a0TextField3.getText()); //Sub Total//
                cost[5] = Double.parseDouble(a0TextField4.getText()); //Total//

//                int r = 1235 + (int)(Math.random()*4238);

                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("\tdd/MM/yyyy\t\tHH:mm:ss");

                textArea1.append("\t\nCafe Management System:\n\n"+"Latte:\t\t\t"+drinks[0]
                                                                  +"\nIced Latte:\t\t\t"+drinks[1]
                                                                  +"\nEspresso:\t\t\t"+drinks[2]
                                                                  +"\nCappuccino:\t\t\t"+drinks[3]
                                                                  +"\nIced Cappuccino:\t\t"+drinks[4]
                                                                  +"\n          ========================================="
                                                                  +"\nCoffee Cake:\t\t\t"+cakes[0]
                                                                  +"\nRedVelvet Cake:\t\t"+cakes[1]
                                                                  +"\nBoston Cream Pie:\t\t"+cakes[2]
                                                                  +"\nBlackForest Cake:\t\t"+cakes[3]
                                                                  +"\nLagos Chocolate Cake:\t\t"+cakes[4]
                                                                  +"\nKilburn Chocolate Cake:\t\t"+cakes[5]
                                                                  +"\nCarltonHill Chocolate Cake:\t\t"+cakes[6]
                                                                  +"\nQueen's Park Chocolate Cake:\t\t"+cakes[7]
                                                                  +"\n          ========================================="
                                                                  +"\nTax:\t"+cost[3]+" Baht"
                                                                  +"\nSub Total:\t"+cost[4]+" Baht"
                                                                  +"\nTotal:\t"+cost[5]+" Baht"
                                                                  +"\n          ========================================="
                                                                  +"\n\n"+dtf.format(LocalDateTime.now())
                                                                  +"\n\n\t\tThank You");

            }
        });
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource().equals(resetButton)){
                    latteCheckBox.setSelected(false);
                    icedLatteCheckBox.setSelected(false);
                    espressoCheckBox.setSelected(false);
                    cappuccinoCheckBox.setSelected(false);
                    icedCappuccinoCheckBox.setSelected(false);
                    coffeeCakeCheckBox.setSelected(false);
                    queenSParkChocolateCheckBox.setSelected(false);
                    redVelvetCakeCheckBox.setSelected(false);
                    bostonCreamPieCheckBox.setSelected(false);
                    blackForestCakeCheckBox.setSelected(false);
                    lagosChocolateCakeCheckBox.setSelected(false);
                    kilburnChocolateCakeCheckBox.setSelected(false);
                    carltonHillChocolateCakeCheckBox.setSelected(false);

                    textField1.setText("0");
                    textField2.setText("0");
                    textField3.setText("0");
                    textField4.setText("0");
                    textField5.setText("0");
                    textField6.setText("0");
                    textField7.setText("0");
                    textField8.setText("0");
                    textField9.setText("0");
                    textField10.setText("0");
                    textField11.setText("0");
                    textField12.setText("0");
                    textField13.setText("0");
                    a0TextField.setText("0");
                    a0TextField1.setText("0");
                    a0TextField2.setText("0");
                    a0TextField3.setText("0");
                    a0TextField4.setText("0");
                    a10TextField.setText("10");
                    textArea1.setText(null);
                }
            }
        });
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource().equals(exitButton)){
                        System.exit(0);
                }
            }
        });
        //==========Button ActionListener==========//


        //==========CheckBox MouseListener==========//
               //==========Beverage==========//
        latteCheckBox.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                double costLatte = Double.parseDouble(a0TextField.getText());
                double Latte = Double.parseDouble(textField1.getText());
                double price = 40;

                if(latteCheckBox.isSelected()){
                    i[0] = (Latte * price) + costLatte;
                    String Price_Drink = String.format("%.2f",i[0]);
                    a0TextField.setText(Price_Drink);
                }
            }
        });
        icedLatteCheckBox.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                double costLatte = Double.parseDouble(a0TextField.getText());
                double icedLatte = Double.parseDouble(textField2.getText());
                double price = 50;

                if(icedLatteCheckBox.isSelected()){
                    i[1] = (icedLatte * price) + costLatte;
                    String Price_Drink = String.format("%.2f",i[1]);
                    a0TextField.setText(Price_Drink);
                }
            }
        });
        espressoCheckBox.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                double costEspresso = Double.parseDouble(a0TextField.getText());
                double Espresso = Double.parseDouble(textField3.getText());
                double price = 35;

                if(espressoCheckBox.isSelected()){
                    i[2] = (Espresso * price) + costEspresso;
                    String Price_Drink = String.format("%.2f",i[2]);
                    a0TextField.setText(Price_Drink);
                }
            }
        });
        cappuccinoCheckBox.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                double costCappuccino = Double.parseDouble(a0TextField.getText());
                double Cappuccino = Double.parseDouble(textField4.getText());
                double price = 45;

                if(cappuccinoCheckBox.isSelected()){
                    i[3] = (Cappuccino * price) + costCappuccino;
                    String Price_Drink = String.format("%.2f",i[3]);
                    a0TextField.setText(Price_Drink);
                }
            }
        });
        icedCappuccinoCheckBox.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                double costIcedCappuccino = Double.parseDouble(a0TextField.getText());
                double IcedCappuccino = Double.parseDouble(textField5.getText());
                double price = 55;

                if(icedCappuccinoCheckBox.isSelected()){
                    i[4] = (IcedCappuccino * price) + costIcedCappuccino;
                    String Price_Drink = String.format("%.2f",i[4]);
                    a0TextField.setText(Price_Drink);
                }
            }
        });


        //==========Cake==========//
        coffeeCakeCheckBox.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                double costCoffeeCake = Double.parseDouble(a0TextField1.getText());
                double coffeeCake = Double.parseDouble(textField6.getText());
                double price = 80;

                if(coffeeCakeCheckBox.isSelected()){
                    i[5] = (coffeeCake * price) + costCoffeeCake;
                    String Price_Cake = String.format("%.2f",i[5]);
                    a0TextField1.setText(Price_Cake);
                }
            }
        });
        redVelvetCakeCheckBox.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                double costRedVelvetCake = Double.parseDouble(a0TextField1.getText());
                double RedVelvetCake = Double.parseDouble(textField7.getText());
                double price = 80;

                if(redVelvetCakeCheckBox.isSelected()){
                    i[6] = (RedVelvetCake * price) + costRedVelvetCake;
                    String Price_Cake = String.format("%.2f",i[6]);
                    a0TextField1.setText(Price_Cake);
                }
            }
        });
        bostonCreamPieCheckBox.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                double costBostonCreamPie = Double.parseDouble(a0TextField1.getText());
                double bostonCreamPie = Double.parseDouble(textField8.getText());
                double price = 80;

                if(bostonCreamPieCheckBox.isSelected()){
                    i[7] = (bostonCreamPie * price) + costBostonCreamPie;
                    String Price_Cake = String.format("%.2f",i[7]);
                    a0TextField1.setText(Price_Cake);
                }
            }
        });
        blackForestCakeCheckBox.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                double costBlackForestCake = Double.parseDouble(a0TextField1.getText());
                double blackForestCake = Double.parseDouble(textField9.getText());
                double price = 80;

                if(blackForestCakeCheckBox.isSelected()){
                    i[8] = (blackForestCake * price) + costBlackForestCake;
                    String Price_Cake = String.format("%.2f",i[8]);
                    a0TextField1.setText(Price_Cake);
                }
            }
        });
        lagosChocolateCakeCheckBox.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                double costLagosChocolateCake = Double.parseDouble(a0TextField1.getText());
                double lagosChocolateCake = Double.parseDouble(textField10.getText());
                double price = 80;

                if(lagosChocolateCakeCheckBox.isSelected()){
                    i[9] = (lagosChocolateCake * price) + costLagosChocolateCake;
                    String Price_Cake = String.format("%.2f",i[9]);
                    a0TextField1.setText(Price_Cake);
                }
            }
        });
        kilburnChocolateCakeCheckBox.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                double costKilburnChocolateCake = Double.parseDouble(a0TextField1.getText());
                double kilburnChocolateCake = Double.parseDouble(textField11.getText());
                double price = 80;

                if(kilburnChocolateCakeCheckBox.isSelected()){
                    i[10] = (kilburnChocolateCake * price) + costKilburnChocolateCake;
                    String Price_Cake = String.format("%.2f",i[10]);
                    a0TextField1.setText(Price_Cake);
                }
            }
        });
        carltonHillChocolateCakeCheckBox.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                double costCarltonHillChocolateCake = Double.parseDouble(a0TextField1.getText());
                double carltonHillChocolateCake = Double.parseDouble(textField12.getText());
                double price = 80;

                if(carltonHillChocolateCakeCheckBox.isSelected()){
                    i[11] = (carltonHillChocolateCake * price) + costCarltonHillChocolateCake;
                    String Price_Cake = String.format("%.2f",i[11]);
                    a0TextField1.setText(Price_Cake);
                }
            }
        });
        queenSParkChocolateCheckBox.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                double costQueenSParkChocolate = Double.parseDouble(a0TextField1.getText());
                double queenSParkChocolate = Double.parseDouble(textField13.getText());
                double price = 80;

                if(queenSParkChocolateCheckBox.isSelected()){
                    i[12] = (queenSParkChocolate * price) + costQueenSParkChocolate;
                    String Price_Cake = String.format("%.2f",i[12]);
                    a0TextField1.setText(Price_Cake);
                }
            }
        });
        //==========CheckBox MouseListener==========//
    }

    public static void main(String[] args) {
        Prototype prototype = new Prototype();
        prototype.setTitle("Cafe Management Systems");
        prototype.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        prototype.setVisible(true);
        prototype.setSize(1300,730);
    }
}